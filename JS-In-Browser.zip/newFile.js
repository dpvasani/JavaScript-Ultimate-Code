document.body.style.background = "yellow";
