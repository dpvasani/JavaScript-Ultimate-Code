// Element Tab -> All Element 
// Onsole Tab -> All The Error Plus Logs 
// Network Tab -> All The Network Request And Requirement

// External File For Js  -> File Cache Ho Jati he So Website Fast WOrk Karti He 
// We Can Add Js In Script Tag Also
// <script src="script.js"></script>
// <script></script>

// Separation Of Concern and Cashing

// Js Console Object
// console.log(console)
// console.error(error)
// console.assert(assert)
// console.clear()
// console.table(table)
// console.warn(warn)
// console.info(info)
// console.time(time)
// console.timeEnd(timeEnd)

// List All Method
// console.log(console)

// Output And Return Type Is There
// console.log("Hey Darshan")
// Output : 
// Hey Darshan 
// Undefined 

// Alert Prompt And Confirm
// Alert -> Alert Box Show Karta Hai
// Prompt -> Prompt Box Show Karta Hai -> Input Lene Ke Liye
// Confirm -> Confirm Box Show Karta Hai -> Yes Or No Lene Ke Liye

// alert("Enter The Value Of A")
// let a = prompt("Enter A Here: ")
// let a = prompt("Enter A Here: ", "578") // Default Value
// document.write(a)


// Confirm -> Yes Or No Lene Ke Liye
// let write = confirm("Do You Want To Write It To The Page")
// if (write) {
//   document.write(a)
// } else {
//   document.write("Please Allow Me To Write")
// }

// This Will Stop Screen Exicution Thats Why Not Suggested To Use That In User Side Plus Look Like Olde Vintage Website So -> Use In Admin Panel 

// BOM And DOM

// BOM -> Browser Object Model
// DOM -> Document Object Model
console.log(window)
// window.console.log(window) -> Same Work Above 

// window is global object under that -> Bom , Dom , Js Core Feture Lies 

// Apke Pure HTML Page ko Document Represent Karta Hai -> Pure Page Ka Object Banke Usko Document Name De Diya Gaya He
console.log(document)
document.body.style.background = "yellow"



//                 BOM (Browser Object Model):
// The Browser Object Model represents the browser window or tab itself. It provides additional objects and properties that allow you to control the browser's behavior and interact with the user. The window object acts as the global object in JavaScript and serves as the entry point to the BOM. It provides properties and methods to control the browser's behavior, such as window.location to manipulate the URL, window.alert() to display alert messages, and window.open() to open new browser windows or tabs.


// Location href = "https://dpvasani56.com"  -> Redirect To Another URL

// console.log(window) => All Method
// Window  Object -> Global Object
